package com.example.calrvkhotijatuzzahro

class DataGambar (val gambar: Int ,val Nis: String,val Nama:String,val Jurusan:String,val Kelas: String) {

}
